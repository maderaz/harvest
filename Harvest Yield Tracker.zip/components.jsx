// Yield tracker homepage — original design
// Components exported to window for consumption by app.jsx

const { useState, useMemo, useEffect } = React;

/* ——————————————————— data ——————————————————— */

const TICKER = [
  { sym: "BTC", price: "67,412.90", chg: +0.82 },
  { sym: "ETH", price: "3,284.15", chg: +1.21 },
  { sym: "SOL", price: "172.44", chg: -2.14 },
  { sym: "XRP", price: "0.6218", chg: +0.44 },
  { sym: "USDC", price: "1.0001", chg: +0.00 },
  { sym: "USDT", price: "1.0000", chg: -0.01 },
  { sym: "stETH", price: "3,281.02", chg: +1.18 },
  { sym: "LINK", price: "14.88", chg: -0.92 },
];

const STRIP = [
  ["Total TVL Tracked", "$142.6B", +1.2],
  ["Avg Stablecoin APY", "6.84%", +0.31],
  ["Avg ETH Staking APY", "3.12%", -0.04],
  ["Avg BTC Yield APY", "2.76%", +0.11],
  ["Active Protocols", "318", +2],
  ["Chains Indexed", "47", 0],
];

const ASSETS = {
  USDC: { color: "#2775CA", mono: "U" },
  USDT: { color: "#26A17B", mono: "T" },
  DAI:  { color: "#F4B731", mono: "D" },
  ETH:  { color: "#627EEA", mono: "E" },
  stETH:{ color: "#00A3FF", mono: "s" },
  BTC:  { color: "#F7931A", mono: "B" },
  wBTC: { color: "#F09242", mono: "w" },
  XRP:  { color: "#23292F", mono: "X" },
  SOL:  { color: "#9945FF", mono: "S" },
  MATIC:{ color: "#8247E5", mono: "M" },
};

const POOLS = [
  { rank: 1, protocol: "Aave v3", cat: "Lending", asset: "USDC", chain: "Ethereum", apy: 9.24, tvl: 1284.6, reward: 0.0, d7: 8.91, d30: 7.84, risk: "Low" },
  { rank: 2, protocol: "Morpho Blue", cat: "Lending", asset: "USDC", chain: "Ethereum", apy: 11.82, tvl: 612.4, reward: 2.1, d7: 12.04, d30: 10.66, risk: "Low" },
  { rank: 3, protocol: "Pendle", cat: "Yield Trading", asset: "stETH", chain: "Ethereum", apy: 14.06, tvl: 488.2, reward: 0.0, d7: 13.51, d30: 12.18, risk: "Med" },
  { rank: 4, protocol: "Lido", cat: "Staking", asset: "ETH", chain: "Ethereum", apy: 3.18, tvl: 32140.0, reward: 0.0, d7: 3.14, d30: 3.21, risk: "Low" },
  { rank: 5, protocol: "Babylon", cat: "Restaking", asset: "BTC", chain: "Bitcoin", apy: 6.42, tvl: 1890.1, reward: 1.8, d7: 6.28, d30: 5.91, risk: "Med" },
  { rank: 6, protocol: "Kamino", cat: "Lending", asset: "USDC", chain: "Solana", apy: 12.44, tvl: 244.8, reward: 3.2, d7: 11.98, d30: 10.02, risk: "Med" },
  { rank: 7, protocol: "Ethena", cat: "Synthetic", asset: "USDT", chain: "Ethereum", apy: 22.18, tvl: 3210.5, reward: 0.0, d7: 24.10, d30: 19.44, risk: "High" },
  { rank: 8, protocol: "Rootstock", cat: "Lending", asset: "wBTC", chain: "Rootstock", apy: 4.08, tvl: 88.4, reward: 0.0, d7: 3.92, d30: 4.21, risk: "Med" },
  { rank: 9, protocol: "Spark", cat: "Lending", asset: "DAI", chain: "Ethereum", apy: 8.15, tvl: 1940.3, reward: 0.0, d7: 8.02, d30: 7.88, risk: "Low" },
  { rank: 10, protocol: "Flare LP", cat: "Liquidity", asset: "XRP", chain: "Flare", apy: 7.64, tvl: 42.1, reward: 4.1, d7: 7.21, d30: 6.98, risk: "Med" },
  { rank: 11, protocol: "Ondo", cat: "RWA", asset: "USDC", chain: "Ethereum", apy: 5.22, tvl: 610.8, reward: 0.0, d7: 5.20, d30: 5.14, risk: "Low" },
  { rank: 12, protocol: "Symbiotic", cat: "Restaking", asset: "ETH", chain: "Ethereum", apy: 8.80, tvl: 1211.6, reward: 2.4, d7: 8.62, d30: 7.41, risk: "Med" },
  { rank: 13, protocol: "Marinade", cat: "Staking", asset: "SOL", chain: "Solana", apy: 7.28, tvl: 1744.0, reward: 0.0, d7: 7.22, d30: 7.18, risk: "Low" },
  { rank: 14, protocol: "Yearn v3", cat: "Vault", asset: "USDC", chain: "Ethereum", apy: 10.66, tvl: 312.9, reward: 0.0, d7: 10.28, d30: 9.80, risk: "Low" },
  { rank: 15, protocol: "Curve 3pool", cat: "Liquidity", asset: "DAI", chain: "Ethereum", apy: 3.44, tvl: 184.2, reward: 0.6, d7: 3.31, d30: 3.28, risk: "Low" },
  { rank: 16, protocol: "Drift", cat: "Perps LP", asset: "USDC", chain: "Solana", apy: 18.44, tvl: 142.1, reward: 6.2, d7: 19.02, d30: 16.88, risk: "High" },
  { rank: 17, protocol: "Compound v3", cat: "Lending", asset: "USDC", chain: "Base", apy: 7.91, tvl: 421.6, reward: 1.2, d7: 7.84, d30: 7.60, risk: "Low" },
  { rank: 18, protocol: "EigenLayer", cat: "Restaking", asset: "ETH", chain: "Ethereum", apy: 5.18, tvl: 12400.0, reward: 0.0, d7: 5.12, d30: 4.98, risk: "Med" },
];

const CATEGORIES = [
  { name: "Lending", count: 84, apy: "8.14%" },
  { name: "Staking", count: 42, apy: "4.22%" },
  { name: "Restaking", count: 28, apy: "6.88%" },
  { name: "Liquidity", count: 66, apy: "9.44%" },
  { name: "Yield Trading", count: 14, apy: "12.06%" },
  { name: "RWA", count: 22, apy: "5.18%" },
  { name: "Vault", count: 38, apy: "10.12%" },
  { name: "Synthetic", count: 8,  apy: "18.40%" },
];

/* ——————————————————— tiny primitives ——————————————————— */

function AssetDot({ asset, size = 20 }) {
  const a = ASSETS[asset] || { color: "#999", mono: asset[0] };
  return (
    <span className="asset-dot" style={{ background: a.color, width: size, height: size, fontSize: size * 0.5 }}>
      {a.mono}
    </span>
  );
}

function Delta({ v, suffix = "%" }) {
  if (v === 0) return <span className="delta neutral">0.00{suffix}</span>;
  const pos = v > 0;
  return (
    <span className={"delta " + (pos ? "up" : "down")}>
      {pos ? "▲" : "▼"} {Math.abs(v).toFixed(2)}{suffix}
    </span>
  );
}

function Spark({ points, up = true, w = 68, h = 22 }) {
  const max = Math.max(...points);
  const min = Math.min(...points);
  const range = max - min || 1;
  const d = points.map((p, i) => {
    const x = (i / (points.length - 1)) * w;
    const y = h - ((p - min) / range) * (h - 2) - 1;
    return `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  const last = points.map((p, i) => {
    const x = (i / (points.length - 1)) * w;
    const y = h - ((p - min) / range) * (h - 2) - 1;
    return [x, y];
  }).slice(-1)[0];
  const color = up ? "var(--up)" : "var(--down)";
  return (
    <svg width={w} height={h} className="spark">
      <path d={`${d} L${w},${h} L0,${h} Z`} fill={color} opacity="0.08" />
      <path d={d} fill="none" stroke={color} strokeWidth="1.25" />
      <circle cx={last[0]} cy={last[1]} r="1.8" fill={color} />
    </svg>
  );
}

function seedSpark(seed, up) {
  // deterministic fake series
  const out = [];
  let v = 50;
  for (let i = 0; i < 24; i++) {
    const n = Math.sin(seed * 12.9898 + i * 78.233) * 43758.5453;
    const r = n - Math.floor(n);
    v += (r - 0.5) * 8 + (up ? 0.4 : -0.4);
    out.push(v);
  }
  return out;
}

/* ——————————————————— chrome ——————————————————— */

function TopNav({ onToggleTheme, dark }) {
  const items = ["Discover", "USDC", "ETH", "Bitcoin", "Protocols", "Chains", "Portfolio"];
  return (
    <header className="topnav">
      <div className="topnav-inner">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 20 20" width="20" height="20">
              <rect x="1" y="11" width="3" height="7" fill="currentColor" />
              <rect x="6" y="7" width="3" height="11" fill="currentColor" />
              <rect x="11" y="3" width="3" height="15" fill="currentColor" />
              <rect x="16" y="8" width="3" height="10" fill="currentColor" opacity="0.5" />
            </svg>
          </div>
          <span className="brand-name">Harvest</span>
        </div>
        <nav className="navlinks">
          {items.map((i, idx) => (
            <a key={i} href="#" className={idx === 0 ? "active" : ""}>{i}</a>
          ))}
        </nav>
        <div className="nav-right">
          <label className="search">
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" />
            </svg>
            <input placeholder="Search pool, protocol, asset…" />
            <kbd>⌘K</kbd>
          </label>
          <button className="iconbtn" onClick={onToggleTheme} title="Toggle theme">
            {dark ? "☀" : "☾"}
          </button>
          <button className="btn-primary">Connect Wallet</button>
        </div>
      </div>
    </header>
  );
}

function TickerStrip() {
  return (
    <div className="ticker">
      <div className="ticker-track">
        {[...TICKER, ...TICKER].map((t, i) => (
          <span key={i} className="ticker-item">
            <AssetDot asset={t.sym} size={14} />
            <span className="t-sym">{t.sym}</span>
            <span className="t-price mono">${t.price}</span>
            <Delta v={t.chg} />
          </span>
        ))}
      </div>
    </div>
  );
}

/* ——————————————————— hero ——————————————————— */

function Hero() {
  return (
    <section className="hero">
      <div className="hero-left">
        <div className="crumbs mono">DISCOVER / YIELDS</div>
        <h1>
          Earn the best yield onchain.<br />
          <span className="dim">Discover USDC, ETH, Bitcoin and XRP opportunities across 47 chains.</span>
        </h1>
        <div className="hero-actions">
          <button className="btn-primary">Browse all pools →</button>
          <button className="btn-ghost">How we rank</button>
          <span className="hero-meta mono">
            Updated <span className="pulse" /> 12s ago · 318 protocols tracked
          </span>
        </div>
      </div>
      <div className="hero-right">
        {STRIP.map((s, i) => (
          <div key={i} className="stat-tile">
            <div className="stat-label">{s[0]}</div>
            <div className="stat-val mono">{s[1]}</div>
            <Delta v={s[2]} suffix={typeof s[2] === "number" && Math.abs(s[2]) > 5 ? "" : "%"} />
          </div>
        ))}
      </div>
    </section>
  );
}

/* ——————————————————— filter bar ——————————————————— */

const FILTERS = {
  asset: ["All", "USDC", "USDT", "DAI", "ETH", "BTC", "XRP", "SOL"],
  chain: ["All chains", "Ethereum", "Solana", "Base", "Bitcoin", "Flare", "Rootstock"],
  category: ["All types", "Lending", "Staking", "Restaking", "Liquidity", "Vault", "RWA", "Yield Trading", "Synthetic", "Perps LP"],
  risk: ["Any risk", "Low", "Med", "High"],
};

function FilterBar({ filters, setFilters, query, setQuery }) {
  const Pill = ({ k, options }) => (
    <select className="pill" value={filters[k]} onChange={(e) => setFilters({ ...filters, [k]: e.target.value })}>
      {options.map((o) => <option key={o} value={o}>{o}</option>)}
    </select>
  );
  return (
    <div className="filterbar">
      <div className="fb-left">
        <Pill k="asset" options={FILTERS.asset} />
        <Pill k="chain" options={FILTERS.chain} />
        <Pill k="category" options={FILTERS.category} />
        <Pill k="risk" options={FILTERS.risk} />
      </div>
      <div className="fb-right">
        <label className="search small">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="11" cy="11" r="7" /><path d="M20 20l-3.5-3.5" />
          </svg>
          <input placeholder="Filter pools…" value={query} onChange={(e) => setQuery(e.target.value)} />
        </label>
        <div className="viewtoggle">
          <button className="active">Table</button>
          <button>Cards</button>
        </div>
        <button className="iconbtn ghost" title="Export">⇩</button>
      </div>
    </div>
  );
}

/* ——————————————————— ranking table ——————————————————— */

function RankingTable({ rows }) {
  const [sort, setSort] = useState({ key: "apy", dir: "desc" });
  const sorted = useMemo(() => {
    const arr = [...rows];
    arr.sort((a, b) => {
      const va = a[sort.key], vb = b[sort.key];
      if (typeof va === "string") return sort.dir === "asc" ? va.localeCompare(vb) : vb.localeCompare(va);
      return sort.dir === "asc" ? va - vb : vb - va;
    });
    return arr;
  }, [rows, sort]);

  const Head = ({ k, children, align = "right" }) => (
    <th
      className={"th " + align + (sort.key === k ? " sorted" : "")}
      onClick={() => setSort({ key: k, dir: sort.key === k && sort.dir === "desc" ? "asc" : "desc" })}
    >
      {children}
      {sort.key === k && <span className="caret">{sort.dir === "desc" ? "▾" : "▴"}</span>}
    </th>
  );

  const fmtTvl = (v) => v >= 1000 ? `$${(v / 1000).toFixed(2)}B` : `$${v.toFixed(1)}M`;
  const riskColor = (r) => r === "Low" ? "ok" : r === "Med" ? "warn" : "bad";

  return (
    <div className="table-wrap">
      <table className="ranking">
        <thead>
          <tr>
            <Head k="rank" align="left">#</Head>
            <Head k="protocol" align="left">Protocol / Pool</Head>
            <Head k="chain" align="left">Chain</Head>
            <Head k="apy">APY</Head>
            <Head k="reward">Reward</Head>
            <Head k="d7">7d avg</Head>
            <Head k="d30">30d avg</Head>
            <Head k="tvl">TVL</Head>
            <Head k="risk" align="left">Risk</Head>
            <th className="th center">30d</th>
            <th className="th"></th>
          </tr>
        </thead>
        <tbody>
          {sorted.map((r) => {
            const up = r.apy >= r.d30;
            return (
              <tr key={r.rank} className="row">
                <td className="td rank mono">{r.rank}</td>
                <td className="td">
                  <div className="proto">
                    <AssetDot asset={r.asset} size={22} />
                    <div>
                      <div className="proto-name">{r.protocol}</div>
                      <div className="proto-sub mono">{r.asset} · {r.cat}</div>
                    </div>
                  </div>
                </td>
                <td className="td"><span className="chip">{r.chain}</span></td>
                <td className="td right mono big">
                  <span className={"apy " + (r.apy >= 10 ? "hot" : "")}>{r.apy.toFixed(2)}%</span>
                </td>
                <td className="td right mono">{r.reward ? `+${r.reward.toFixed(1)}%` : "—"}</td>
                <td className="td right mono dim">{r.d7.toFixed(2)}%</td>
                <td className="td right mono dim">{r.d30.toFixed(2)}%</td>
                <td className="td right mono">{fmtTvl(r.tvl)}</td>
                <td className="td"><span className={"risk " + riskColor(r.risk)}>{r.risk}</span></td>
                <td className="td center">
                  <Spark points={seedSpark(r.rank, up)} up={up} />
                </td>
                <td className="td right">
                  <button className="row-cta">Deposit</button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
      <div className="table-foot">
        <span className="mono dim">Showing {sorted.length} of 318 pools</span>
        <div className="pager">
          <button>‹</button>
          <button className="active">1</button>
          <button>2</button>
          <button>3</button>
          <button>…</button>
          <button>27</button>
          <button>›</button>
        </div>
      </div>
    </div>
  );
}

/* ——————————————————— right rail ——————————————————— */

function CategoryGrid() {
  return (
    <section className="card section">
      <div className="section-head">
        <h3>Browse by strategy</h3>
        <a href="#" className="link">All categories →</a>
      </div>
      <div className="cat-grid">
        {CATEGORIES.map((c) => (
          <div key={c.name} className="cat-tile">
            <div className="cat-top">
              <span className="cat-name">{c.name}</span>
              <span className="cat-count mono dim">{c.count}</span>
            </div>
            <div className="cat-apy mono">{c.apy}</div>
            <div className="cat-foot dim mono">avg APY</div>
          </div>
        ))}
      </div>
    </section>
  );
}

function FeaturedAsset({ asset, apy, tvl, change, pools }) {
  return (
    <div className="feat">
      <div className="feat-head">
        <AssetDot asset={asset} size={28} />
        <div>
          <div className="feat-name">{asset}</div>
          <div className="feat-sub mono dim">{pools} pools</div>
        </div>
        <Delta v={change} />
      </div>
      <div className="feat-body">
        <div>
          <div className="feat-label mono dim">Best APY</div>
          <div className="feat-val mono">{apy}</div>
        </div>
        <div>
          <div className="feat-label mono dim">Total TVL</div>
          <div className="feat-val mono">{tvl}</div>
        </div>
        <Spark points={seedSpark(asset.charCodeAt(0), change > 0)} up={change > 0} w={96} h={34} />
      </div>
    </div>
  );
}

function AssetsSection() {
  const list = [
    { asset: "USDC", apy: "12.44%", tvl: "$48.2B", change: +0.42, pools: 84 },
    { asset: "ETH",  apy: "8.80%",  tvl: "$52.1B", change: +0.18, pools: 46 },
    { asset: "BTC",  apy: "6.42%",  tvl: "$14.8B", change: +1.12, pools: 18 },
    { asset: "XRP",  apy: "7.64%",  tvl: "$2.1B",  change: -0.24, pools: 6 },
  ];
  return (
    <section className="card section">
      <div className="section-head">
        <h3>Featured assets</h3>
        <div className="tabs">
          <button className="active">Top</button>
          <button>Stable</button>
          <button>LSTs</button>
          <button>RWA</button>
        </div>
      </div>
      <div className="feat-grid">
        {list.map((a) => <FeaturedAsset key={a.asset} {...a} />)}
      </div>
    </section>
  );
}

function MoversCard({ title, items, positive }) {
  return (
    <div className="card movers">
      <div className="section-head compact">
        <h4>{title}</h4>
        <a className="link" href="#">View →</a>
      </div>
      <ul className="mov-list">
        {items.map((it, i) => (
          <li key={i}>
            <span className="mov-left">
              <span className="mov-rank mono dim">{i + 1}</span>
              <AssetDot asset={it.asset} size={18} />
              <span className="mov-name">{it.name}</span>
            </span>
            <span className="mov-right mono">
              <span className="mov-apy">{it.apy}</span>
              <Delta v={positive ? it.chg : -it.chg} suffix="%" />
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function MoversSection() {
  const gainers = [
    { name: "Ethena sUSDe", asset: "USDT", apy: "22.18%", chg: 4.02 },
    { name: "Drift JLP",    asset: "USDC", apy: "18.44%", chg: 2.88 },
    { name: "Pendle PT",    asset: "stETH",apy: "14.06%", chg: 2.41 },
    { name: "Morpho USDC",  asset: "USDC", apy: "11.82%", chg: 1.96 },
    { name: "Yearn USDC",   asset: "USDC", apy: "10.66%", chg: 1.44 },
  ];
  const losers = [
    { name: "Rootstock wBTC", asset: "wBTC", apy: "4.08%", chg: 1.32 },
    { name: "Lido ETH",       asset: "ETH",  apy: "3.18%", chg: 0.41 },
    { name: "Curve 3pool",    asset: "DAI",  apy: "3.44%", chg: 0.28 },
    { name: "Compound v3",    asset: "USDC", apy: "7.91%", chg: 0.22 },
    { name: "Marinade",       asset: "SOL",  apy: "7.28%", chg: 0.12 },
  ];
  const newPools = [
    { name: "Symbiotic ETH", asset: "ETH", apy: "8.80%", chg: 0.00 },
    { name: "Babylon BTC",   asset: "BTC", apy: "6.42%", chg: 0.00 },
    { name: "Flare XRP LP",  asset: "XRP", apy: "7.64%", chg: 0.00 },
    { name: "Kamino USDC",   asset: "USDC",apy: "12.44%",chg: 0.00 },
    { name: "Ondo OUSG",     asset: "USDC",apy: "5.22%", chg: 0.00 },
  ];
  return (
    <section className="movers-grid">
      <MoversCard title="Top gainers · 24h" items={gainers} positive />
      <MoversCard title="Top losers · 24h" items={losers} positive={false} />
      <MoversCard title="Newly listed" items={newPools} positive />
    </section>
  );
}

/* ——————————————————— footer ——————————————————— */

function FootBar() {
  return (
    <footer className="foot">
      <div className="foot-inner">
        <div className="foot-brand">
          <span className="brand-name">Harvest</span>
          <span className="mono dim"> · Independent onchain yield index</span>
        </div>
        <div className="foot-links mono">
          <a href="#">API</a><a href="#">Methodology</a><a href="#">Risk framework</a>
          <a href="#">Docs</a><a href="#">Status</a><a href="#">Terms</a>
        </div>
        <div className="mono dim">© 2026 · Data delayed ≤ 60s</div>
      </div>
    </footer>
  );
}

/* ——————————————————— export ——————————————————— */

Object.assign(window, {
  TopNav, TickerStrip, Hero, FilterBar, RankingTable,
  CategoryGrid, AssetsSection, MoversSection, FootBar,
  POOLS, AssetDot, Delta, Spark,
});
