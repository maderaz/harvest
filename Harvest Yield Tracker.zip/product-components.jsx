// Product page (vault detail) — generates real-feeling chart data and composes blocks

const { useState, useMemo } = React;

/* ——— deterministic series helpers ——— */
function rand(seed) {
  const x = Math.sin(seed * 9301 + 49297) * 233280;
  return x - Math.floor(x);
}
function genSeries(n, base, vol, drift = 0, seed = 1) {
  const out = [];
  let v = base;
  for (let i = 0; i < n; i++) {
    v += (rand(seed + i) - 0.5) * vol + drift;
    out.push(Math.max(v, base * 0.3));
  }
  return out;
}

/* ——— chart ——— */
function AreaChart({ points, color = "var(--up)", height = 220, peakIdx, peakLabel }) {
  const w = 800;
  const h = height;
  const pad = { l: 40, r: 12, t: 14, b: 8 };
  const plotW = w - pad.l - pad.r;
  const plotH = h - pad.t - pad.b;
  const max = Math.max(...points);
  const min = Math.min(...points);
  const range = max - min || 1;
  const xy = points.map((p, i) => {
    const x = pad.l + (i / (points.length - 1)) * plotW;
    const y = pad.t + plotH - ((p - min) / range) * plotH;
    return [x, y];
  });
  const path = xy.map(([x, y], i) => `${i === 0 ? "M" : "L"}${x.toFixed(1)},${y.toFixed(1)}`).join(" ");
  const area = `${path} L${xy[xy.length - 1][0]},${pad.t + plotH} L${xy[0][0]},${pad.t + plotH} Z`;

  // y-axis labels (3 ticks)
  const ticks = [max, (max + min) / 2, min];

  // peak marker
  const peak = peakIdx != null ? xy[peakIdx] : null;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="chart-svg" preserveAspectRatio="none">
      {/* grid */}
      {ticks.map((t, i) => {
        const y = pad.t + (i / (ticks.length - 1)) * plotH;
        return (
          <g key={i}>
            <line x1={pad.l} x2={w - pad.r} y1={y} y2={y} stroke="var(--line)" strokeDasharray="2 3" />
            <text x={pad.l - 8} y={y + 3} fontSize="10" textAnchor="end"
              fill="var(--ink-4)" fontFamily="var(--mono)">{t.toFixed(2)}</text>
          </g>
        );
      })}
      <path d={area} fill={color} opacity="0.1" />
      <path d={path} fill="none" stroke={color} strokeWidth="1.6" />
      {peak && (
        <g>
          <line x1={peak[0]} x2={peak[0]} y1={pad.t} y2={h - pad.b} stroke="var(--ink-3)" strokeDasharray="3 3" opacity="0.5" />
          <circle cx={peak[0]} cy={peak[1]} r="3.5" fill={color} stroke="var(--panel)" strokeWidth="2" />
          <g transform={`translate(${Math.min(peak[0] + 8, w - 130)}, ${Math.max(peak[1] - 28, pad.t)})`}>
            <rect x="0" y="0" width="118" height="34" rx="6" fill="var(--ink)" />
            <text x="9" y="14" fontSize="10.5" fill="var(--bg-2)" fontFamily="var(--mono)" opacity="0.7">PEAK</text>
            <text x="9" y="28" fontSize="12" fill="#fff" fontFamily="var(--mono)" fontWeight="600">{peakLabel}</text>
          </g>
        </g>
      )}
    </svg>
  );
}

/* ——— main panel: tabs + range + chart ——— */
function PerformancePanel() {
  const [tab, setTab] = useState("apy");
  const [range, setRange] = useState("90D");
  const N = range === "7D" ? 7 : range === "30D" ? 30 : range === "90D" ? 90 : 180;

  const datasets = useMemo(() => ({
    apy: genSeries(180, 55, 9, -0.05, 11).map((v) => Math.abs(v) + 30),
    tvl: genSeries(180, 60, 8, -0.04, 7).map((v) => Math.abs(v) + 12),
    sp:  genSeries(180, 1.7, 0.04, 0.003, 3),
  }), []);
  const fmt = {
    apy: (v) => v.toFixed(2) + "%",
    tvl: (v) => "$" + (v).toFixed(1) + "K",
    sp:  (v) => v.toFixed(4),
  };
  const peaks = {
    apy: { idx: 168, label: "86.91% · Apr 6, 2026" },
    tvl: { idx: 28,  label: "$123K · Feb 22, 2026" },
    sp:  { idx: 165, label: "2.1639 · Apr 4, 2026" },
  };

  const series = datasets[tab].slice(-N);
  const tabs = [
    { k: "apy", label: "APY History", val: "51.58%", sub: "current" },
    { k: "tvl", label: "TVL History", val: "$21K", sub: "current" },
    { k: "sp",  label: "Share Price", val: "2.1639", sub: "+116.39% all time" },
  ];

  const xLabels = range === "7D"
    ? ["Apr 19", "Apr 22", "Apr 26"]
    : range === "30D"
    ? ["Mar 27", "Apr 6", "Apr 16", "Apr 26"]
    : range === "90D"
    ? ["Jan 26", "Feb 25", "Mar 27", "Apr 26"]
    : ["Oct 28", "Dec 27", "Feb 25", "Apr 26"];

  return (
    <div className="charts-card" id="performance">
      <div className="chart-tabs">
        {tabs.map((t) => (
          <button key={t.k} className={"chart-tab " + (tab === t.k ? "active" : "")} onClick={() => setTab(t.k)}>
            <div className="ct-label">{t.label}</div>
            <div className="ct-val">{t.val}</div>
            <div className="ct-sub">{t.sub}</div>
          </button>
        ))}
      </div>
      <div className="chart-body">
        <div className="chart-toolbar">
          <div className="range-pills">
            {["7D", "30D", "90D", "All"].map((r) => (
              <button key={r} className={range === r ? "active" : ""} onClick={() => setRange(r)}>{r}</button>
            ))}
          </div>
          <div className="chart-peak">
            Peak: <b>{peaks[tab].label}</b>
          </div>
        </div>
        <AreaChart
          points={series}
          peakIdx={range === "All" ? peaks[tab].idx : null}
          peakLabel={peaks[tab].label}
        />
        <div className="chart-axis-x">
          {xLabels.map((l) => <span key={l}>{l}</span>)}
        </div>
      </div>
    </div>
  );
}

/* ——— consistency dial ——— */
function ConsistencyCard({ score = 92 }) {
  const r = 38;
  const c = 2 * Math.PI * r;
  const dash = (score / 100) * c;
  return (
    <div className="consistency">
      <div className="consistency-score">
        <svg viewBox="0 0 96 96">
          <circle cx="48" cy="48" r={r} fill="none" stroke="var(--line)" strokeWidth="8" />
          <circle cx="48" cy="48" r={r} fill="none" stroke="var(--up)" strokeWidth="8"
            strokeDasharray={`${dash} ${c}`} strokeLinecap="round" />
        </svg>
        <div className="num">{score}</div>
      </div>
      <div>
        <div className="consistency-label">Very Consistent</div>
        <p style={{ margin: 0, fontSize: 14, lineHeight: 1.55, color: "var(--ink-2)" }}>
          Over the 30 days ending Apr 26, 2026, APY averaged <strong>52.41%</strong> across 18 data points
          with a standard deviation of <strong>7.27%</strong> — indicating reliable, repeatable yield generation.
        </p>
      </div>
    </div>
  );
}

/* ——— yield sources ——— */
function YieldSources() {
  const sources = [
    { name: "AERO", pct: 16.87, of: 51.58 },
    { name: "Trading fees", pct: 8.42, of: 51.58 },
    { name: "USDC base rate", pct: 4.30, of: 51.58 },
    { name: "Compounding boost", pct: 21.99, of: 51.58 },
  ];
  const max = Math.max(...sources.map((s) => s.pct));
  return (
    <div className="ys-bars">
      {sources.map((s) => (
        <div key={s.name} className="ys-row">
          <div className="ys-name">{s.name}</div>
          <div className="ys-bar"><span style={{ width: `${(s.pct / max) * 100}%` }} /></div>
          <div className="ys-val mono">{s.pct.toFixed(2)}%</div>
        </div>
      ))}
    </div>
  );
}

/* ——— calculator ——— */
function Calculator() {
  const [amt, setAmt] = useState(1000);
  const [period, setPeriod] = useState("1Y");
  const apy = 0.5158;
  const months = { "1M": 1/12, "6M": 0.5, "1Y": 1, "2Y": 2 }[period];
  const earn = amt * (Math.pow(1 + apy, months) - 1);
  const fmt = (n) => "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  return (
    <div className="calc-card" id="calculator">
      <h3 style={{ marginTop: 0, fontFamily: "var(--display)", fontSize: 16 }}>Earnings Calculator</h3>
      <div className="calc-label">Deposit Amount (USDC)</div>
      <div className="calc-input">
        <span>$</span>
        <input type="number" value={amt} onChange={(e) => setAmt(Number(e.target.value) || 0)} />
      </div>
      <div className="calc-label">Period</div>
      <div className="calc-period">
        {["1M", "6M", "1Y", "2Y"].map((p) => (
          <button key={p} className={period === p ? "active" : ""} onClick={() => setPeriod(p)}>
            {p === "1M" ? "1 Month" : p === "6M" ? "6 Months" : p === "1Y" ? "1 Year" : "2 Years"}
          </button>
        ))}
      </div>
      <div className="calc-result">
        <div className="cr-block">
          <div className="cr-label">Initial</div>
          <div className="cr-val">{fmt(amt)}</div>
        </div>
        <div className="cr-block">
          <div className="cr-label">Earnings</div>
          <div className="cr-val up">+{fmt(earn)}</div>
        </div>
        <div className="cr-block" style={{ gridColumn: "1 / -1", borderTop: "1px dashed var(--line)", paddingTop: 8 }}>
          <div className="cr-label">Total Value</div>
          <div className="cr-val total">{fmt(amt + earn)}</div>
        </div>
      </div>
      <div className="calc-disclaimer mono">
        Estimates assume constant 51.58% APY. Actual returns will vary with market conditions.
      </div>
    </div>
  );
}

/* ——— deposit card (sticky) ——— */
function DepositCard() {
  const [mode, setMode] = useState("Deposit");
  const [amt, setAmt] = useState("");
  const num = parseFloat(amt) || 0;
  const yearly = num * 0.5158;
  const monthly = yearly / 12;
  const fmt = (n) => "$" + n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

  return (
    <div className="deposit-card">
      <div className="dep-apy-row">
        <div>
          <div className="dep-tag">CURRENT APY · 24H</div>
          <div className="dep-apy">51.58%</div>
        </div>
        <div style={{ textAlign: "right" }}>
          <div className="dep-tag">30D AVG</div>
          <div className="mono" style={{ fontSize: 18, fontWeight: 600 }}>52.67%</div>
        </div>
      </div>
      <div className="dep-tabs">
        {["Deposit", "Withdraw"].map((m) => (
          <button key={m} className={mode === m ? "active" : ""} onClick={() => setMode(m)}>{m}</button>
        ))}
      </div>
      <div className="dep-bal">
        <span>Wallet balance</span>
        <a>2,438.21 USDC</a>
      </div>
      <div className="dep-input">
        <input type="text" placeholder="0.00" value={amt} onChange={(e) => setAmt(e.target.value)} />
        <span className="dep-asset">
          <span className="asset-dot" style={{ background: "#2775CA", width: 20, height: 20, fontSize: 10 }}>U</span>
          USDC
        </span>
      </div>
      <div className="dep-quick">
        {["25%", "50%", "75%", "Max"].map((q) => (
          <button key={q} onClick={() => setAmt(String((2438.21 * (q === "Max" ? 1 : parseInt(q)/100)).toFixed(2)))}>{q}</button>
        ))}
      </div>
      <button className="dep-cta">{mode} USDC →</button>
      <div className="dep-projection">
        <div>
          <div className="dp-l">Est. monthly</div>
          <div className="dp-v">+{fmt(monthly)}</div>
        </div>
        <div>
          <div className="dp-l">Est. yearly</div>
          <div className="dp-v">+{fmt(yearly)}</div>
        </div>
      </div>
    </div>
  );
}

/* ——— TOC ——— */
function TOC() {
  const items = [
    { id: "about", label: "About this vault" },
    { id: "performance", label: "Performance history" },
    { id: "overview", label: "Performance overview" },
    { id: "consistency", label: "APY consistency" },
    { id: "sources", label: "Yield sources" },
    { id: "calculator", label: "Earnings calculator" },
    { id: "details", label: "Contract details" },
    { id: "faq", label: "FAQ" },
    { id: "more", label: "More USDC vaults" },
  ];
  return (
    <div className="side-card toc">
      <h4>On this page</h4>
      <ul>
        {items.map((i) => <li key={i.id}><a href={`#${i.id}`}>{i.label}</a></li>)}
      </ul>
    </div>
  );
}

/* ——— FAQ ——— */
const FAQS = [
  { q: "What is the current APY for USDC Aerodrome?",
    a: "USDC Aerodrome currently generates a 24-hour APY of 51.58% and a 30-day average APY of 52.67%. Yields are sourced from AERO emissions, trading fees, and the USDC base rate, with a compounding boost from automatic harvesting." },
  { q: "What chain is USDC Aerodrome on?",
    a: "The USDC Aerodrome vault is deployed on Base, an Ethereum Layer 2 rollup. Deposits, withdrawals and harvesting all happen onchain on Base." },
  { q: "How does USDC Aerodrome work?",
    a: "USDC Aerodrome is an autocompounder: it deposits your USDC into the underlying Aerodrome strategy, periodically harvests the AERO token rewards, swaps them back to USDC, and redeposits — compounding your returns without any manual restaking." },
  { q: "What is the TVL of USDC Aerodrome?",
    a: "USDC Aerodrome currently holds $21K in total value locked (TVL). The all-time TVL peak was $123K, reached on Feb 22, 2026." },
  { q: "Is USDC Aerodrome an Autocompounder or Autopilot?",
    a: "USDC Aerodrome is an Autocompounder. Harvest also offers Autopilot vaults, which dynamically reallocate funds between strategies; this vault sits in a single Aerodrome strategy and reinvests its rewards automatically." },
  { q: "How stable is the APY for USDC Aerodrome?",
    a: "Over the trailing 30 days the APY scored 92/100 on Harvest's consistency index, with a standard deviation of 7.27% across 18 data points — categorising it as Very Consistent." },
  { q: "Where does the yield come from for USDC Aerodrome?",
    a: "Yield is generated from AERO emissions (16.87%), Aerodrome trading fees (8.42%), USDC base rate (4.30%), and the autocompounding boost (21.99%) — combining for a 24h APY of 51.58%." },
];

function FAQ() {
  return (
    <div className="faq" id="faq">
      {FAQS.map((f, i) => (
        <details key={i} open={i === 0}>
          <summary>{f.q}</summary>
          <p>{f.a}</p>
        </details>
      ))}
    </div>
  );
}

/* ——— more vaults ——— */
function MoreVaults() {
  const vaults = [
    { name: "USDC Prime",            by: "Harvest Finance", apy: 36.00, tvl: "$89K" },
    { name: "USDC Gauntlet Frontier",by: "Harvest Finance", apy: 24.12, tvl: "$287K" },
    { name: "USDC Clearstar Core V2",by: "Harvest Finance", apy: 18.48, tvl: "$6K" },
    { name: "USDC Fluid",            by: "Harvest Finance", apy: 18.32, tvl: "$360K" },
  ];
  return (
    <div className="more-vaults" id="more">
      {vaults.map((v) => (
        <a className="mv-card" href="#" key={v.name}>
          <div className="mv-head">
            <span className="asset-dot" style={{ background: "#2775CA", width: 30, height: 30, fontSize: 14 }}>U</span>
            <div>
              <div className="mv-name">{v.name}</div>
              <div className="mv-by">{v.by}</div>
            </div>
          </div>
          <div className="mv-stats">
            <div>
              <div>APY</div>
              <div className="mv-num up">{v.apy.toFixed(2)}%</div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div>TVL</div>
              <div className="mv-num">{v.tvl}</div>
            </div>
          </div>
        </a>
      ))}
    </div>
  );
}

Object.assign(window, {
  AreaChart, PerformancePanel, ConsistencyCard, YieldSources,
  Calculator, DepositCard, TOC, FAQ, MoreVaults,
});
